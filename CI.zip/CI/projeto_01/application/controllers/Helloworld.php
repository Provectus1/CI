<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: pedro
 * Date: 25/04/2019
 * Time: 16:31
 */

    class Helloworld extends CI_Controller{
public function __construct()
{
parent::__construct();
//load model
$this->load->model('helloworld_model');
}

public function index()
{
//get data from the database
$data['result'] = $this->helloworld_model->getData();
//load view and pass the data
$this->load->view('helloworld_view', $data);
}

}